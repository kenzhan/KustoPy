# KustoPy
A collection of Python utility functions for querying and ingesting data in Azure Data Explorer (Kusto) 
