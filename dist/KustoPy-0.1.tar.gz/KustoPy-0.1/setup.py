from setuptools import setup

setup(
    name='KustoPy',
    packages=['KustoPy'],
    description='A collection of utility function for Azure Data Explorer (Kusto)',
    version='0.1',
    url='https://github.com/kenzhan/KustoPy',
    author='Ken',
    author_email='kenneth_zh@msn.com',
    keywords=['pip','Kusto','Azure Data Explorer']
    )